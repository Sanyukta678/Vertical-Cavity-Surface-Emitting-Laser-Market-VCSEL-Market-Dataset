# VCSEL (Vertical Cavity Surface Emitting Laser) Market Dataset
This dataset includes structured public information from the VCSEL Market page on NextMSC.

Files:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- toc.txt

License: MIT
